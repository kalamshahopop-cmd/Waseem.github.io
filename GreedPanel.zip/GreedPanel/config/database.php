<?php
/*
 * ============================================================
 *  Made by Bapan | Date: 5/4/2026
 *  All credits belongs to Bapan
 *  For any kind of software development job, cheat, website
 *  or panel development — contact Bapan:
 *  Telegram: https://t.me/bapanff
 *  Official Channel: https://t.me/greedv0
 * ============================================================
 */
return [
    'host' => 'localhost',
    'name' => 'u352183376_greed',
    'user' => 'u352183376_greed',
    'pass' => 'Bapanff69@',
    'charset' => 'utf8mb4'
];
